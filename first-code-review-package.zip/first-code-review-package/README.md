# Helpful instructions for reviewer

To better demonstrate the structure of our project and also because directory path has meaning for url routing in Next.js, I have included folders to accurately show the location of each file within our project.
